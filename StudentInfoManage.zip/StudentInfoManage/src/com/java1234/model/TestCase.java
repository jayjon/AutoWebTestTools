package com.java1234.model;

public class TestCase {
	private int id;
	private String testCaseName;
	private String testCasetype;
	private String testCaseSteps;
	private String expectedResult;
	private String actualResult;

	public TestCase(String testCaseName, String testCasetype,
			String testCaseSteps, String expectedResult,String actualResult) {
		super();
		this.testCaseName = testCaseName;
		this.testCasetype = testCasetype;
		this.testCaseSteps = testCaseSteps;
		this.expectedResult = expectedResult;
		this.actualResult = actualResult;
	}
	public TestCase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTestCaseName() {
		return testCaseName;
	}
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	public String getTestCasetype() {
		return testCasetype;
	}
	public void setTestCasetype(String testCasetype) {
		this.testCasetype = testCasetype;
	}
	public String getTestCaseSteps() {
		return testCaseSteps;
	}
	public void setTestCaseSteps(String testCaseSteps) {
		this.testCaseSteps = testCaseSteps;
	}
	public String getExpectedResult() {
		return expectedResult;
	}
	public void setExpectedResult(String expectedResult) {
		this.expectedResult = expectedResult;
	}
	public String getActualResult(){
		return actualResult;
	}
	public void setActualResult(String actualResult){
		this.actualResult =actualResult;
	}
	

}
