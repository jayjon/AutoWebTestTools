package com.java1234.model;

import java.util.Date;

public class Teacher {
	
	private String teaNo;
	private String teaName;
	private String sex;
	private Date birthday;
	private int teaId;
	private String email;
	private String teaDesc;
	//�޲������췽��
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	//�в����Ĺ��췽��
	public Teacher( String teaNo, String teaName, String sex,
			Date birthday,int teaId, String email, String teaDesc) {
		super();
		this.teaId = teaId;
		this.teaNo = teaNo;
		this.teaName = teaName;
		this.sex = sex;
		this.birthday = birthday;
		this.email = email;
		this.teaDesc = teaDesc;
	}
	//get set ����
	public int getTeaId() {
		return teaId;
	}
	
	public void setTeaId(int teaId) {
		this.teaId = teaId;
	}
	public String getTeaNo() {
		return teaNo;
	}
	public void setTeaNo(String teaNo) {
		this.teaNo = teaNo;
	}
	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTeaDesc() {
		return teaDesc;
	}
	public void setTeaDesc(String teaDesc) {
		this.teaDesc = teaDesc;
	}
	
}
