package com.java1234.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.java1234.dao.TestCaseDao;
import com.java1234.dao.UserDao;
import com.java1234.model.Grade;
import com.java1234.model.PageBean;
import com.java1234.model.TestCase;
import com.java1234.model.User;
import com.java1234.util.DbUtil;
import com.java1234.util.JsonUtil;
import com.java1234.util.ResponseUtil;
import com.java1234.util.StringUtil;

public class TestCaseListServlet extends HttpServlet{
	DbUtil dbUtil=new DbUtil();
	TestCaseDao testCaseDao=new TestCaseDao();
	
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page=request.getParameter("page");
		String rows=request.getParameter("rows");
		String testCaseName=request.getParameter("testCaseName");
		if(testCaseName==null){
			testCaseName="";
		}
		TestCase testCase=new TestCase();
		testCase.setTestCaseName(testCaseName);
		PageBean pageBean=new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Connection con=null;
		try{
			con=dbUtil.getCon();
			JSONObject result=new JSONObject();
			JSONArray jsonArray=JsonUtil.formatRsToJsonArray(testCaseDao.testCaseList(con, pageBean, testCase));
			int total=testCaseDao.testCaseCount(con, testCase);
			result.put("rows", jsonArray);
			result.put("total", total);
			ResponseUtil.write(response, result);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	
	
}
