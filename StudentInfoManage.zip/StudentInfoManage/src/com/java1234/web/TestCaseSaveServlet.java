package com.java1234.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.java1234.dao.GradeDao;
import com.java1234.dao.TestCaseDao;
import com.java1234.dao.UserDao;
import com.java1234.model.Grade;
import com.java1234.model.PageBean;
import com.java1234.model.TestCase;
import com.java1234.model.User;
import com.java1234.util.DbUtil;
import com.java1234.util.JsonUtil;
import com.java1234.util.ResponseUtil;
import com.java1234.util.StringUtil;

public class TestCaseSaveServlet extends HttpServlet{
	DbUtil dbUtil=new DbUtil();
	TestCaseDao testCaseDao=new TestCaseDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String testCaseName=request.getParameter("testCaseName");
		String testCasetype=request.getParameter("testCasetype");
		String testCaseSteps=request.getParameter("testCaseSteps");
		String expectedResult=request.getParameter("expectedResult");
		String actualResult=request.getParameter("actualResult");
		String id=request.getParameter("id");
		TestCase testCase=new TestCase(testCaseName,testCasetype,testCaseSteps,expectedResult,actualResult);
		if(StringUtil.isNotEmpty(id)){
			testCase.setId(Integer.parseInt(id));
		}
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int saveNums=0;
			JSONObject result=new JSONObject();
			if(StringUtil.isNotEmpty(id)){
				saveNums=testCaseDao.testCaseModify(con, testCase);
			}else{
				saveNums=testCaseDao.testCaseAdd(con, testCase);
			}
			if(saveNums>0){
				result.put("success", "true");
			}else{
				result.put("success", "true");
				result.put("errorMsg", "����ʧ��");
			}
			ResponseUtil.write(response, result);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	
}
