package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.Grade;
import com.java1234.model.PageBean;
import com.java1234.model.TestCase;
import com.java1234.model.User;
import com.java1234.util.StringUtil;


public class TestCaseDao {

	/**
	 * ��¼��֤
	 * @param con
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public ResultSet testCaseList(Connection con,PageBean pageBean,TestCase testCase)throws Exception{
		StringBuffer sb=new StringBuffer("select * from t_testCase");
		if(testCase!=null && StringUtil.isNotEmpty(testCase.getTestCaseName())){
			sb.append(" and testCase like '%"+testCase.getTestCaseName()+"%'");
		}
		if(pageBean!=null){
			sb.append(" limit "+pageBean.getStart()+","+pageBean.getRows());
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	//ͳ���û��ĸ���
	public int testCaseCount(Connection con,TestCase testCase)throws Exception{
		StringBuffer sb=new StringBuffer("select count(*) as total from t_testCase");
		if(StringUtil.isNotEmpty(testCase.getTestCaseName())){
			sb.append(" and testCase like '%"+testCase.getTestCaseName()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			return rs.getInt("total");
		}else{
			return 0;
		}
	}
	/**
	 * delete from tableName where field in (1,3,5)
	 * @param con
	 * @param delIds
	 * @return
	 * @throws Exception
	 */
	public int testCaseDelete(Connection con,String delIds)throws Exception{
		String sql="delete from t_testCase where id in("+delIds+")";
		PreparedStatement pstmt=con.prepareStatement(sql);
		return pstmt.executeUpdate();
	}
	
	public int testCaseAdd(Connection con,TestCase testCase)throws Exception{
		String sql="insert into t_testCase values(null,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, testCase.getTestCaseName());
		pstmt.setString(2, testCase.getTestCasetype());
		pstmt.setString(3, testCase.getTestCaseSteps());
		pstmt.setString(4, testCase.getExpectedResult());
		pstmt.setString(5, testCase.getActualResult());
		return pstmt.executeUpdate();
	}
	
	public int testCaseModify(Connection con,TestCase testCase)throws Exception{
		String sql="update t_testCase set testCaseName=?,testCasetype=?,testCaseSteps? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, testCase.getTestCaseName());
		pstmt.setString(2, testCase.getTestCasetype());
		pstmt.setString(3, testCase.getTestCaseSteps());
		pstmt.setInt(4, testCase.getId());
		return pstmt.executeUpdate();
	}

	
}
