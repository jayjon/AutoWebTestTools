package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java1234.model.PageBean;
import com.java1234.model.Student;
import com.java1234.model.Teacher;
import com.java1234.util.DateUtil;
import com.java1234.util.StringUtil;

public class TeacherDao {
    public ResultSet TeacherList(Connection con,PageBean pageBean,Teacher teacher,String bbirthday,String ebirthday) throws SQLException{
		StringBuffer  sb =new StringBuffer("select *��from t_teacher t");
    	if(StringUtil.isNotEmpty(teacher.getTeaNo())){
    		sb.append("and t.teaNo like '%"+teacher.getTeaNo()+"%'");
    	}
    	if(StringUtil.isNotEmpty(teacher.getTeaName())){
    		sb.append("and t.teaName like '%"+teacher.getTeaName()+"%'");
    	}
    	
    	if(StringUtil.isNotEmpty(teacher.getSex())){
    		sb.append("and t.teaSex like '%"+teacher.getSex()+"%'");
    	}
    	if(teacher.getTeaId()!=0){
    		sb.append("and t.teaId = '"+teacher.getTeaId()+"'");
    	}
    	
    	if(StringUtil.isNotEmpty(bbirthday)){
			sb.append(" and TO_DAYS(s.birthday)>=TO_DAYS('"+bbirthday+"')");
		}
		if(StringUtil.isNotEmpty(ebirthday)){
			sb.append(" and TO_DAYS(s.birthday)<=TO_DAYS('"+ebirthday+"')");
		}
    	if(StringUtil.isNotEmpty(teacher.getEmail())){
    		sb.append("and t.teaEmail like '%"+teacher.getEmail()+"%'");
    	}
    	if(StringUtil.isNotEmpty(teacher.getTeaDesc())){
    		sb.append("and t.teaDesc like '%"+teacher.getTeaDesc()+"%'");
    	}
    	
		if(pageBean!=null){
			sb.append(" limit "+pageBean.getStart()+","+pageBean.getRows());
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString());
		return pstmt.executeQuery();
		
    	
    }
    //ɾ������
    public int teacherDelete(Connection con,String delIds)throws Exception{
		String sql="delete from t_teacher where teaId in("+delIds+")";
		PreparedStatement pstmt=con.prepareStatement(sql);
		return pstmt.executeUpdate();
	}
    //���ӷ���
    public int teacherAdd(Connection con,Teacher teacher)throws Exception{
		String sql="insert into t_teacher values(null,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1,teacher.getTeaNo());
		pstmt.setString(2, teacher.getTeaName());
		pstmt.setString(3, teacher.getSex());
		pstmt.setInt(4, teacher.getTeaId());
		pstmt.setString(5, DateUtil.formatDate(teacher.getBirthday(), "yyyy-MM-dd"));
		pstmt.setString(6, teacher.getEmail());
		pstmt.setString(7, teacher.getTeaDesc());
		return pstmt.executeUpdate();
	}
    public int teaModify(Connection con,Teacher teacher)throws Exception{
		String sql="update t_teacher set teaNo=?,teaName=?,sex=?,birthday=?,TeaId=?,email=?,TeaDesc=? where TeaId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacher.getTeaNo());
		pstmt.setString(2, teacher.getTeaName());
		pstmt.setString(3, teacher.getSex());
		
		pstmt.setInt(4, teacher.getTeaId());
		pstmt.setString(5, DateUtil.formatDate(teacher.getBirthday(), "yyyy-MM-dd"));
		pstmt.setString(6, teacher.getEmail());
		pstmt.setString(7, teacher.getTeaDesc());
		
		return pstmt.executeUpdate();
    }
    
}
