package com.gw.jython;


import java.io.BufferedReader;
import java.io.InputStreamReader;




import com.gw.jython.TestExecPython;

public class Main   
{  
    public static void main(String[] args)   
    {  
        /*TestExecPython.INSTANCE.test();
    	 PythonInterpreter interpreter = new PythonInterpreter();
         interpreter.exec("print('hello')");*/
         String[] arguments = new String[] {"python", "D:\\Users\\Administrator\\Workspaces\\project1\\test.py"};
         try {
             Process process = Runtime.getRuntime().exec(arguments);
             BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
             String line = null;  
           while ((line = in.readLine()) != null) {  
               System.out.println("AA"+line);  
           }  
           in.close();  
           int re = process.waitFor();  
           System.out.println("BB"+re);
         } catch (Exception e) {
             e.printStackTrace();
         }  
    }  
  
}  
