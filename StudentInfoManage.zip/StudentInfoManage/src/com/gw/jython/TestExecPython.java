package com.gw.jython;

import java.util.HashMap;
import java.util.Map;

public enum TestExecPython {
   INSTANCE;
public void test()  
{  
    String scriptFile = "test.py";  
    Map<String,String> properties = new HashMap<String,String>();  
    properties.put("userName", "Demo");  
      
    ExecPython.INSTANCE.execute(scriptFile, properties);  
}  
public static class main{
	public static void main(String[] args){
		TestExecPython.INSTANCE.test();
	}
}
}
