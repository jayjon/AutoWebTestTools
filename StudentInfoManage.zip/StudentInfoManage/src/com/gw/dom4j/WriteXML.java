package com.gw.dom4j;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import com.java1234.model.User;

public class WriteXML {
	public static void main(String[] args) throws Exception  
	{  
	     Document document = DocumentHelper.createDocument();  
	     document.setXMLEncoding("GBK");  
	     Element root = document.addElement("users");  
	     root.addNamespace("", "http://www.abc.com/ns/test");  
	     root.addNamespace("t", "http://www.abc.com/ns/test");  
	     root.addNamespace("xsi","http://www.w3.org/2001/XMLSchema-instance");  
	     root.addAttribute("xsi:schemaLocation", "http://www.abc.com/ns/test student.xsd");  
	     //QName qname = DocumentFactory.getInstance().createQName("schemaLocation", "xsi", "http://www.abc.com/ns/test student.xsd");  
	     //root.addAttribute(qname,"http://www.abc.com/ns/test student.xsd");  
	  
	  
	     User[] u= new User[2];  
	  
	  
	     u[0] = new User("aa","1234");  
	     u[1] = new User("bb","123456"); 
	     for (int i = 0; i < u.length; i++) {  
	         User user = u[i];  
	         Element e1 = root.addElement("user","http://www.abc.com/ns/test");  
	           
	         //e1.addNamespace("", "http://www.abc.com/ns/test");  
	           
	         Namespace n1 = e1.getNamespace();  
	         Namespace n2 = e1.getNamespaceForPrefix("");  
	         Namespace n3 = e1.getNamespaceForURI("http://www.abc.com/ns/test");  
	         //e1.remove(n1); e1.remove(n2); e1.remove(n3);  
	         //e1.addElement("id").addText(toString(user.getId()));
	         e1.addElement("name").addText(user.getUserName());  
	         e1.addElement("password").addText(user.getPassword());  
	        
	        }  
	     FileOutputStream fos = new FileOutputStream("user.xml");  
	     OutputStreamWriter osw = new OutputStreamWriter(fos,"GBK");  
	     OutputFormat of = new OutputFormat();  
	     of.setEncoding("GBK");  
	     of.setIndent(true);  
	     of.setIndent("    ");  
	     of.setNewlines(true);  
	     XMLWriter writer = new XMLWriter(osw, of);  
	     writer.write(document);  
	     writer.close();  
	    }

	private static String toString(int id) {
		// TODO Auto-generated method stub
		return null;
	}  
}
