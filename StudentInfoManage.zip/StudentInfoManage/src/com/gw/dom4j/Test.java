package com.gw.dom4j;

import javax.swing.text.html.parser.Parser;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	  String xmlFileName ="D:\\Users\\Administrator\\Workspaces\\project1\\user.xml";
	  PraseXml prasexml = new PraseXml();
      prasexml.parse3Xml(xmlFileName);
    
      
	}

}
