import urllib.request
url = "http://demo.zentao.net/user-login-Lw==.html"
url1 = "http://http://demo.zentao.net/bug-browse.html"
page_info = urllib.request.urlopen(url).read()
page_info = page_info.decode('utf-8')
print(page_info,"sssssssssssssssssssssss")
page_info = urllib.request.urlopen(url1).read()
page_info = page_info.decode('utf-8')
print(page_info)

